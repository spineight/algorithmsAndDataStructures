#include <iostream>
#include <cstdio>
#include <algorithm>
#include <fcntl.h>
#include <io.h>
#include <cmath>
#include "UniqueCounter.h"

using namespace std;

int main()
{
    _setmode( fileno( stdin ), _O_BINARY );
    uint N;
    fread(&N, sizeof(uint), 1, stdin);
    UniqueCounter counter(N);
    for (uint i = 0; i < N; i++) {
        uint x;
        fread(&x, sizeof(uint), 1, stdin);
        counter.process(x);
    }
    uint ans;
    fread(&ans, sizeof(uint), 1, stdin);
    double out = counter.predict();
    printf("Out: %.2lf\nCorrect: %u\n", out, ans);
    return 0;
}
