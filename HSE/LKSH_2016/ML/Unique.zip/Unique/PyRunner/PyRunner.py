# -*- coding: utf-8 -*-
"""
Created on Tue Aug 23 12:14:24 2016

@author: student
"""

import sys
import UniqueModule


def read_number():
    x = sys.stdin.buffer.read(4)
    return int.from_bytes(x, 'little')
    


N = read_number()
counter = UniqueModule.UniqueCounter(N)

for i in range(N):
    x = read_number()
    counter.process(x)

cout = counter.predict() 
ans = read_number()
print('Out: %.2f\nCorrect: %u' % (cout, ans))
#print('Object memory: ', sys.getsizeof(counter))