# -*- coding: utf-8 -*-
"""
Created on Tue Aug 23 16:56:14 2016

@author: student
"""


min_number = 0
max_number = 0xffffffff

"""
    Вам предлагается релизовать класс UniqueCounter,
    в классе обязательно должны присутствовать:
        * конструктор __init__(self, N), в который передается число N, 
                обозначающее количетсво чисел во входном потоке.
                В конструкторе вы можете инициализировать
                всe необходимые структуры данных. Все переменные дожны быть 
                выделены внутри класса, использование глобальных переменных
                запрещено;
                                      
        * метод process(self, x), который производит обработку очередного
                числа x из входного потока;
                                  
        * метод predict(self), который возвращает вещественное 
                число --- оценку количества различных значений во входном 
                потоке;                                 
            
"""

class UniqueCounter:
    def __init__(self, N):
        self.mn = max_number
        self.mx = min_number
        self.cnt = 0
    
    def process(self, x):
        self.mn = min(self.mn, x)
        self.mx = max(self.mx, x)
        self.cnt += 1
        
    def predict(self):
        return min(self.mx - self.mn + 1, self.cnt)
